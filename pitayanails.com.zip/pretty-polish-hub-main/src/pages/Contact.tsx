import { VisitUs } from '@/components/VisitUs';

const Contact = () => {
  return (
    <div className="min-h-screen pt-24 pb-12">
      <VisitUs />
    </div>
  );
};

export default Contact;